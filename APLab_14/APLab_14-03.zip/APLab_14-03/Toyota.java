import java.util.Random;

public class Toyota extends Car
{
	Random rand = new Random();
	public Toyota(String z)
	{
		
	}
}
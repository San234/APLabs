import java.util.Random;

public class GMC extends Car
{
	Random rand = new Random(); 
	public GMC(double h, double v)
	{
		
	}
}
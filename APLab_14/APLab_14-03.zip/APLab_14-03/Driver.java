import java.util.Random;

public class Driver
{
	public static void main(String[]args)
	{
		Random rand = new Random();
		
		for(NavigationSystem )
	}
}
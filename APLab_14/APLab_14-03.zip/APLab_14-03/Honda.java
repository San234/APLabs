import java.util.Random;

public class Honda extends Car 
{
	Random rand = new Random(); 
	public Honda(double[] l)
	{
		
	}
}
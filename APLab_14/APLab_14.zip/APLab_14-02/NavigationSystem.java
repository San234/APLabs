public interface NavigationSystem
{
	double[] getLoc();
	int getID();
	void move(double x, double y);
}
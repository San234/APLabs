public interface NavigationSystem
{
	double[] getLoc();
	int getID();
}
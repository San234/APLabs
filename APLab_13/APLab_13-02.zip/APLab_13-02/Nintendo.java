public class Nintendo extends Console
{
	public Nintendo()
	{
		super();
	}
	public Nintendo(String p)
	{
		super(p);
	}
	public String getController()
	{
		return "Buttons";
	}
	public String getPlatform()
	{
		return "Nintendo DS";
	}
}
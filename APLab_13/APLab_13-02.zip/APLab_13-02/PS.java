public class PS extends Console
{
	public PS()
	{
		super();
	}
	public PS(String p)
	{
		super(p);
	}
	public String getController()
	{
		return "PS DualShock 3";
	}
	public String getPlatform()
	{
		return "PlayStation";
	}
}